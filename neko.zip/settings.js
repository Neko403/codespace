// settings.js
module.exports = {
    // Konfigurasi utama bot
    token: '7967980491:AAHub5-OCVEQSFGynOpMr29Fx51ImRwj8Ew',
    adminId: '6898114344',
    pp: 'https://files.catbox.moe/b8fj6f.jpg',
    
    // Konfigurasi Pterodactyl
    domain: 'https://your-panel.domain.com',
    plta: 'ptla_your_application_key',
    pltc: 'ptlc_your_client_key',
    eggs: '15',
    loc: '1',
    
    // Konfigurasi Cloudflare
    cloudflare: {
        domain: 'paanel.web.id',
        zoneId: 'feab67d312471e04a21d37a9a5719cbf',
        apiToken: 'B6ASbk0FUwO79d_EcGNmMmzlsiWGUeJceSxKTTic',
        apiBase: 'https://api.cloudflare.com/client/v4'
    }
};