const TelegramBot = require("node-telegram-bot-api");
const { Client } = require("ssh2");
const { exec } = require("child_process");
const fs = require("fs");
const path = require("path")
const axios = require("axios");
const settings = require("./settings");
const owner = settings.adminId;
const botToken = settings.token;
const adminfile = "adminID.json";
const premiumUsersFile = "premiumUsers.json";
let domain = settings.domain;
let plta = settings.plta;
let pltc = settings.pltc;

// Cloudflare configuration dari settings
const CF_DOMAIN = settings.cloudflare.domain;
const CF_ZONE_ID = settings.cloudflare.zoneId;
const CF_API_TOKEN = settings.cloudflare.apiToken;
const CF_API_BASE = settings.cloudflare.apiBase;

try {
  premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
  console.error("Error reading premiumUsers file:", error);
}
const bot = new TelegramBot(botToken, { polling: true });
try {
  adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
  console.error("Error reading adminUsers file:", error);
}

// Fungsi Cloudflare yang sudah disederhanakan
function cloudflareHeaders() {
  return {
    Authorization: `Bearer ${CF_API_TOKEN}`,
    'Content-Type': 'application/json',
  };
}

// Fungsi cek DNS record yang sudah ada
async function findDnsRecord(fullName) {
  try {
    const url = `${CF_API_BASE}/zones/${CF_ZONE_ID}/dns_records?type=A&name=${encodeURIComponent(fullName)}`;
    const res = await axios.get(url, { headers: cloudflareHeaders() });
    
    if (!res.data || !res.data.success) return null;
    const records = res.data.result || [];
    return records.length ? records[0] : null;
  } catch (error) {
    console.error('Error finding DNS record:', error.message);
    return null;
  }
}

// Fungsi buat DNS record baru
async function createDnsRecord(fullName, ip, proxied = true) {
  try {
    const url = `${CF_API_BASE}/zones/${CF_ZONE_ID}/dns_records`;
    const body = {
      type: 'A',
      name: fullName,
      content: ip,
      ttl: 1,
      proxied: Boolean(proxied),
    };
    const res = await axios.post(url, body, { headers: cloudflareHeaders() });
    return res.data;
  } catch (error) {
    console.error('Error creating DNS record:', error.message);
    throw error;
  }
}

// Fungsi csubdo yang sudah disederhanakan
const csubdo = async (subdomain, ipAddress) => {
  try {
    const fullName = `${subdomain}.${CF_DOMAIN}`;
    
    // Cek apakah subdomain sudah ada
    const existing = await findDnsRecord(fullName);
    
    if (existing) {
      return { 
        success: false, 
        message: `❌ SUBDOMAIN "${fullName}" SUDAH TERDAFTAR — GUNAKAN NAMA LAIN!` 
      };
    }

    // Buat record baru
    const created = await createDnsRecord(fullName, ipAddress, true);
    
    if (created.success) {
      return { 
        success: true, 
        message: `✅ SUBDOMAIN BERHASIL DIBUAT!\n\n📝 DETAIL:\n• Subdomain: ${fullName}\n• IP Address: ${ipAddress}\n• TTL: 1\n• Proxied: true\n• Record ID: ${created.result.id}`
      };
    } else {
      const errorMsg = created.errors ? created.errors.map(e => e.message).join('; ') : 'Unknown error from Cloudflare API';
      return { success: false, message: `❌ Gagal membuat subdomain: ${errorMsg}` };
    }
  } catch (error) {
    console.error('Error creating subdomain:', error.response?.data || error.message);
    
    let errorMessage = `❌ ERROR: ${error.message}`;
    if (error.response?.data?.errors) {
      errorMessage += `\nDetail: ${error.response.data.errors.map(e => e.message).join(', ')}`;
    }
    
    return { success: false, message: errorMessage };
  }
};

function isValidIP(ip) {
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRegex.test(ip)) return false;
    
    const parts = ip.split('.');
    return parts.every(part => {
        const num = parseInt(part, 10);
        return num >= 0 && num <= 255;
    });
}
function isValidSubdomain(subdomain) {
    const subdomainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$/;
    return subdomainRegex.test(subdomain) && subdomain.length >= 1 && subdomain.length <= 63;
}
function readSettings() {
  try {
    const settingsPath = path.join(__dirname, 'settings.js');
    return fs.readFileSync(settingsPath, 'utf8');
  } catch (error) {
    throw new Error(`Gagal membaca file settings: ${error.message}`);
  }
}
function writeSettings(newContent) {
  try {
    const settingsPath = path.join(__dirname, 'settings.js');
    fs.writeFileSync(settingsPath, newContent, 'utf8');
    return true;
  } catch (error) {
    throw new Error(`Gagal menulis file settings: ${error.message}`);
  }
}
function updateSettings(newDomain, newPlta, newPltc) {
  try {
    const currentContent = readSettings();
    
    // Regex yang lebih spesifik untuk menghindari replace yang salah
    const domainRegex = /(\s*domain\s*:\s*)'[^']*'/;
    const pltaRegex = /(\s*plta\s*:\s*)'[^']*'/;
    const pltcRegex = /(\s*pltc\s*:\s*)'[^']*'/;
    
    let newContent = currentContent;
    newContent = newContent.replace(domainRegex, `$1'${newDomain}'`);
    newContent = newContent.replace(pltaRegex, `$1'${newPlta}'`);
    newContent = newContent.replace(pltcRegex, `$1'${newPltc}'`);
    
    const success = writeSettings(newContent);
    
    if (success) {
      // Update variabel global
      domain = newDomain;
      plta = newPlta;
      pltc = newPltc;
      
      // Reload settings module
      delete require.cache[require.resolve('./settings')];
      const newSettings = require('./settings');
      
      return true;
    }
    
    return false;
    
  } catch (error) {
    throw new Error(`Gagal update settings: ${error.message}`);
  }
}
const sendMessage = (chatId, text) => bot.sendMessage(chatId, text);
function generateRandomPassword() {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*";
  const length = 10;
  let password = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}
function getRuntime(startTime) {
  const uptime = process.uptime();
  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);
  return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}
// File untuk logging
const logFile = "bot.log";

// Fungsi untuk menulis log ke file dan console
function logToFileAndConsole(message) {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;
  console.log(logMessage);
  fs.appendFileSync(logFile, logMessage);
}
global.tempSettingsData = {};

try {
  premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
  console.error("Error reading premiumUsers file:", error);
}

// Scrape proxy dari sumber yang diberikan
async function scrapeProxies() {
  const proxySources = [
    "https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=http&proxy_format=ipport&format=text&timeout=20000",
    "https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt",
    "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt",
    "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt",
    "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
    "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt",
    "https://raw.githubusercontent.com/berkay-digital/Proxy-Scraper/main/proxies.txt",
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
    "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
    "https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
    "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt",
    "https://raw.githubusercontent.com/HumayunShariarHimu/Proxy/main/Anonymous_HTTP_One.md",
    "https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/https.txt",
    "https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/http.txt",
    "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt",
    "https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
    "https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt",
    "https://raw.githubusercontent.com/elliottophellia/proxylist/master/results/http/global/http_checked.txt",
    "https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt",
  ];

  let proxies = [];

  // Hapus file proxy.txt lama
  if (fs.existsSync("proxy.txt")) {
    fs.unlinkSync("proxy.txt");
    logToFileAndConsole("proxy.txt lama berhasil dihapus");
  }

  for (const source of proxySources) {
    try {
      const response = await axios.get(source);
      proxies = proxies.concat(response.data.split("\n"));
    } catch (error) {
      logToFileAndConsole(
        `Error scraping proxies from ${source}: ${error.message}`
      );
    }
  }

  fs.writeFileSync("proxy.txt", proxies.join("\n"));
  logToFileAndConsole("Proxies successfully scraped and saved to proxy.txt");
}

// Mulai dengan scraping proxy saat bot dijalankan
scrapeProxies();
const nama = "NEKO";
const author = "NEKO";
// Informasi waktu mulai bot
const startTime = Date.now();

let photoCache = null;
let photoCachePath = null;

function loadPhotoToCache() {
  if (photoCache) return photoCache;

  const photoPath = path.join(__dirname, "./assets/photos/photo.jpg");
  if (fs.existsSync(photoPath)) {
    photoCachePath = photoPath;
    photoCache = fs.readFileSync(photoPath);
    return photoCache;
  }
  return null;
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Command /updateproxy untuk memperbarui proxy
bot.onText(/\/updateproxy/, (msg) => {
  const chatId = msg.chat.id;
  scrapeProxies();
  const message = "Proxy Updated.";
  bot.sendMessage(chatId, message);
});
// Handler untuk command /proxycount
bot.onText(/\/proxycount/, (msg) => {
  const chatId = msg.chat.id;

  fs.readFile("proxy.txt", "utf8", (err, data) => {
    if (err) {
      bot.sendMessage(
        chatId,
        "Gagal membaca file proxy.txt. Pastikan file tersebut ada dan bisa diakses."
      );
      logToFileAndConsole(`Error reading proxy.txt: ${err.message}`);
      return;
    }

    // Pisahkan setiap baris yang ada di file proxy.txt
    const proxies = data.split("\n").filter(Boolean);
    const proxyCount = proxies.length;

    bot.sendMessage(
      chatId,
      `Jumlah proxy yang ada di proxy.txt: ${proxyCount}`
    );
    logToFileAndConsole(`Sent proxy count: ${proxyCount} to chat ${chatId}`);
  });
});
// Command /ongoing untuk mengecek command yang sedang berjalan
bot.onText(/\/ongoing/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "Tidak ada command yang sedang berjalan.");
  logToFileAndConsole(`Checked ongoing commands for chat ${chatId}`);
});

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const startTime = Date.now();
  const cachedPhoto = loadPhotoToCache();
  
  const menuText = `
╭━━━━━━━━━━━━━━━━━━━❍
┃ ʙᴏᴛ ɴᴀᴍᴇ : ɴᴇᴋᴏ ᴄᴘᴀɴᴇʟ
┃ ᴅᴇᴠᴇʟᴏᴘᴇʀ : t.me/Neneko20
┃ ʙᴜʏ sᴄ : t.me/Neneko20
┃ ᴍʏ ᴄʜᴀɴɴᴇʟ : t.me/nenekostore 
┃ ʀᴜɴᴛɪᴍᴇ : ${getRuntime(startTime)}
╰━━━━━━━━━━━━━━━━━━━❍

╭━━━━━━━━━━━━━━━━━━━❍
┃ [ sᴇʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ ʙᴇʟᴏᴡ ]
╰━━━━━━━━━━━━━━━━━━━❍
©ɴᴇᴋᴏ`;
  // Event listener for button 'My Profil'
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "owner") {
      bot.answerCallbackQuery(callbackQuery.id);
      bot.sendMessage(callbackQuery.from.id, "OWNER @Neneko20");
    }
  });
  // Event listener for button 'Start'
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "start") {
      const chatId = callbackQuery.message.chat.id;
      const startTime = Date.now();

      const menuText = `
─────────────
ketik /start untuk kembali 
ke awal menu
©𝗕𝗬 𝗡𝗘𝗡𝗘𝗞𝗢`;
      const message = menuText;
      const keyboard = {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻CEK ID⿻", callback_data: "cekid" },
          { text: "⿻PAYMENT⿻", callback_data: "payment" },
          { text: "⿻CREATEPANEL⿻", callback_data: "createpanel" },
        ],
        [
          { text: "⿻OWNERMENU⿻", callback_data: "ownermenu" },
          { text: "⿻INSTALLMENU⿻", callback_data: "installmenu" },
          { text: "⿻TESTIMONI⿻", 'url': "t.me/nenekostore" },
        ],
        [
          { text: "⿻OWNER SC⿻", 'url': "t.me/Neneko20" },
        ],
        [
         { text:"⿻ROM PUBLIC⿻", 'url': "https://t.me/nenekopublic" },
            ],
          ],
        },
      };
      bot.answerCallbackQuery(callbackQuery.id);
      bot.editMessageCaption(message, {
        chat_id: chatId,
        message_id: callbackQuery.message.message_id,
        reply_markup: keyboard,
        parse_mode: "Markdown",
      });
    }
  });
  //▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
  // ramlist2
  const message = menuText;
  const keyboard = {
    caption: message,
    reply_markup: {
      inline_keyboard: [
        [
      { text: "⿻CEK ID⿻", callback_data: "cekid" },
          { text: "⿻PAYMENT⿻", callback_data: "payment" },
          { text: "⿻CREATEPANEL⿻", callback_data: "createpanel" },
        ],
        [
          { text: "⿻OWNERMENU⿻", callback_data: "ownermenu" },
          { text: "⿻INSTALLMENU⿻", callback_data: "installmenu" },
          { text: "⿻TESTIMONI⿻", 'url': "t.me/nenekostore" },
        ],
        [
          { text: "⿻OWNER SC⿻", 'url': "t.me/Neneko20" },
        ],
        [
         { text:"⿻ROM PUBLIC⿻", 'url': "https://t.me/nenekopublic" },
        ],
      ],
    },
  };
  bot.sendPhoto(chatId, cachedPhoto, keyboard);
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "createpanel") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "┏━⬣『 CREATE PANEL 』\n│› 1gb user,idtele\n║› 2gb user,idtele\n│› 3gb user,idtele\n║› 4gb user,idtele\n│› 5gb user,idtele\n║› 6gb user,idtele\n│› 7gb user,idtele\n║› 8gb user,idtele\n│› 9gb user,idtele\n║› 10gb user,idtele\n│› unli user,idtele\n║› cadmin user,idtele\n┗━━━━━━━━━━⬣\n  ⿻ Powered By @Neneko20";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
          { text: "⿻CEK ID⿻", callback_data: "cekid" },
          { text: "⿻PAYMENT⿻", callback_data: "payment" },
          { text: "⿻CREATEPANEL⿻", callback_data: "createpanel" },
        ],
        [
          { text: "⿻OWNERMENU⿻", callback_data: "ownermenu" },
          { text: "⿻INSTALLMENU⿻", callback_data: "installmenu" },
          { text: "⿻TESTIMONI⿻", 'url': "t.me/nenekostore" },
        ],
        [
          { text: "⿻OWNER SC⿻", 'url': "t.me/Neneko20" },
        ],
        [
         { text:"⿻ROM PUBLIC⿻", 'url': "https://t.me/nenekopublic" },
        ],
       ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "cekid") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "┏━⌲SILAHKAN CEK ID ANDA\n│\n║› /cekid\n│\n┗━━━━━━━⬣\n  ⿻ Powered By @Neneko20";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "⿻CEK ID⿻", callback_data: "cekid" },
          { text: "⿻PAYMENT⿻", callback_data: "payment" },
          { text: "⿻CREATEPANEL⿻", callback_data: "createpanel" },
        ],
        [
          { text: "⿻OWNERMENU⿻", callback_data: "ownermenu" },
          { text: "⿻INSTALLMENU⿻", callback_data: "installmenu" },
          { text: "⿻TESTIMONI⿻", 'url': "t.me/nenekostore" },
        ],
        [
          { text: "⿻OWNER SC⿻", 'url': "t.me/Neneko20" },
        ],
        [
         { text:"⿻ROM PUBLIC⿻", 'url': "https://t.me/nenekopublic" },
          ],
        ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "installmenu") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "┏━━⬣『 INSTALLMENU 』\n│› /installpanel\n║› /uninstallpanel\n│› /hackback\n║› /installdepend\n│› /stellar\n║› /elysium\n│› /installpanel2\n║› /installprotect1\n│› /installprotect2\n║› /installprotect3\n│› /installprotect4\n║› /installprotect5\n│› /installprotect6\n║› /installprotect7\n│› /installprotect8\n║› /installprotect9\n║› /installprotectall \n│› /uninstallprotect1\n║› /uninstallprotect2\n│› /uninstallprotect3\n║› /uninstallprotect4\n│› /uninstallprotect5\n║› /uninstallprotect6\n│› /uninstallprotect7\n║› /uninstallprotect8\n│› /uninstallprotect9\n│› /uninstallprotectall\n┗━━━━━━━⬣\n  ⿻ Powered By @Neneko20";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
           { text: "⿻CEK ID⿻", callback_data: "cekid" },
          { text: "⿻PAYMENT⿻", callback_data: "payment" },
          { text: "⿻CREATEPANEL⿻", callback_data: "createpanel" },
        ],
        [
          { text: "⿻OWNERMENU⿻", callback_data: "ownermenu" },
          { text: "⿻INSTALLMENU⿻", callback_data: "installmenu" },
          { text: "⿻TESTIMONI⿻", 'url': "t.me/nenekostore" },
        ],
        [
          { text: "⿻OWNER SC⿻", 'url': "t.me/Neneko20" },
        ],
        [
         { text:"⿻ROM PUBLIC⿻", 'url': "https://t.me/nenekopublic" },
          ],
        ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "payment") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "┏━━⬣『 PAYMENTMENU 』\n│› /dana\n║› /gopay\n│› /qris\n║› /ovo\n┗━━━━━━━⬣\n  ⿻ SERTAKAN BUKTI TRANSFER KE ADMIN YA BOS";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
           { text: "⿻CEK ID⿻", callback_data: "cekid" },
          { text: "⿻PAYMENT⿻", callback_data: "payment" },
          { text: "⿻CREATEPANEL⿻", callback_data: "createpanel" },
        ],
        [
          { text: "⿻OWNERMENU⿻", callback_data: "ownermenu" },
          { text: "⿻INSTALLMENU⿻", callback_data: "installmenu" },
          { text: "⿻TESTIMONI⿻", 'url': "t.me/nenekostore" },
        ],
        [
          { text: "⿻OWNER SC⿻", 'url': "t.me/Neneko20" },
        ],
        [
         { text:"⿻ROM PUBLIC⿻", 'url': "https://t.me/nenekopublic" },
          ],
        ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "ownermenu") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "┏━━⬣『 OWNERMENU 』\n│› addowner\n║› addprem\n│› delowner\n║› delprem\n│› listsrv\n║› delsrv\n│› clear\n║› listadmin\n│› setadp\n║› showadp\n│› csubdo\n┗━━━━━━━⬣\n  ⿻ Powered By @Neneko20";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
          { text: "⿻CEK ID⿻", callback_data: "cekid" },
          { text: "⿻PAYMENT⿻", callback_data: "payment" },
          { text: "⿻CREATEPANEL⿻", callback_data: "createpanel" },
        ],
        [
          { text: "⿻OWNERMENU⿻", callback_data: "ownermenu" },
          { text: "⿻INSTALLMENU⿻", callback_data: "installmenu" },
          { text: "⿻TESTIMONI⿻", 'url': "t.me/nenekostore" },
        ],
        [
          { text: "⿻OWNER SC⿻", 'url': "t.me/Neneko20" },
        ],
        [
         { text:"⿻ROM PUBLIC⿻", 'url': "https://t.me/nenekopublic" },
          ],
        ],
      },
    });
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//===================MENU CPANEL===≈====≈============//
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addprem
bot.onText(/\/addprem (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1];

  if (msg.from.id.toString() === owner) {
    if (!premiumUsers.includes(userId)) {
      premiumUsers.push(userId);
      fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
      bot.sendMessage(chatId, `User ${userId} KELAZZ SI HAMA JADI ADMIN BOT NEKO.`);
    } else {
      bot.sendMessage(chatId, `User ${userId} is already a premium user.`);
    }
  } else {
    bot.sendMessage(chatId, "Only the owner can perform this action.");
  }
});
// DANA
bot.onText(/\/dana/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, "DANA\n085336329478\nA/N Di** P**a\n\nSERTAKAN KIRIM PEMBUKTIAN\nTRANSFER KE OWNER,\nUNTUK MELANJUTKAN TRANSAKSI.", {
        'reply_markup' :{
            'inline_keyboard': [[{ 'text': 'CHANEL', 'url': 'https://t.me/nenekostore'},
            { 'text': 'OWNER', 'url': 'https://t.me/Neneko20'}]]
        }
    })
})
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//INSTALL ELYSIUM
bot.onText(/^(\.|\#|\/)elysium$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `Format salah!\nPenggunaan: /elysium ipvps,password`);
  });
// Menangani perintah /installdepend
bot.onText(/\/elysium (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const text = match[1];

    let t = text.split(',');
    if (t.length < 2) {
        return bot.sendMessage(chatId, `Format salah!\nPenggunaan: /elysium ipvps,password`);
    }

    let ipvps = t[0];
    let passwd = t[1];
    

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = 'bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/folderr/refs/heads/main/installp.sh)';

    const conn = new Client();
    let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi

    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        bot.sendMessage(chatId, 'PROSES INSTALL THEME DIMULAI MOHON TUNGGU 1-2 MENIT KEDEPAN');

        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ' + code + ' and signal ' + signal);
                bot.sendMessage(chatId, '`SUKSES INSTALL THEME ELSYUM`');
                conn.end();
            }).on('data', (data) => {
                stream.write('1\n');
                stream.write('y\n');
                stream.write('yes\n');

                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        bot.sendMessage(chatId, 'Katasandi atau IP tidak valid');
    }).connect(connSettings);

    setTimeout(() => {
        if (isSuccess) {
            bot.sendMessage(chatId, '');
        }
    }, 60000); // 180000 ms = 3 menit
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//INSTALL STELLAR
bot.onText(/^(\.|\#|\/)stellar$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `Format salah!\nPenggunaan: /stellar ipvps,password`);
  });
// Menangani perintah /nebula
bot.onText(/\/stellar (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const text = match[1];

    let t = text.split(',');
    if (t.length < 2) {
        return bot.sendMessage(chatId, `Format salah!\nPenggunaan: /stellar ipvps,password`);
    }

    let ipvps = t[0];
    let passwd = t[1];
    

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = 'bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/Installerlex/refs/heads/main/install.sh)';

    const conn = new Client();
    let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi

    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        bot.sendMessage(chatId, 'PROSES INSTALL THEME DIMULAI MOHON TUNGGU 5-10 MENIT KEDEPAN');

        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ' + code + ' and signal ' + signal);
                bot.sendMessage(chatId, '`SUKSES INSTALL THEME PANEL STELLAR, SILAHKAN CEK WEB PANEL ANDA`');
                conn.end();
            }).on('data', (data) => {
                stream.write('1\n');
                stream.write('1\n');
                stream.write('y\n');
                stream.write('x\n');

                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        bot.sendMessage(chatId, 'Katasandi atau IP tidak valid');
    }).connect(connSettings);

    setTimeout(() => {
        if (isSuccess) {
            bot.sendMessage(chatId, '');
        }
    }, 180000); // 180000 ms = 3 menit
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰// CONFIGURE WINGS
bot.onText(/^\/wings (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const text = match[1]; // Diperbaiki dari match[2] menjadi match[1]
    const reply = msg.reply_to_message;

    if (userId !== owner) {
        return bot.sendMessage(chatId, "❌ Akses ditolak! Hanya owner yang dapat menggunakan perintah ini.", {
            reply_to_message_id: reply?.message_id || msg.message_id,
            reply_markup: {
                inline_keyboard: [
                    [{ text: "HUBUNGI ADMIN", url: "https://t.me/Neneko20" }]
                ]
            }
        });
    }

    let t = text.split(',');
    if (t.length < 3) {
        return bot.sendMessage(chatId, `*Format salah!*\nPenggunaan: /wings ipvps,password,token (token configuration)`, { parse_mode: 'Markdown' });
    }

    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    let token = t[2].trim();

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd
    };

    const command = 'bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/Installerlex/refs/heads/main/install.sh)';

    const conn = new Client();

    conn.on('ready', () => {
        bot.sendMessage(chatId, '𝗣𝗥𝗢𝗦𝗘𝗦 𝗖𝗢𝗡𝗙𝗜𝗚𝗨𝗥𝗘 𝗪𝗜𝗡𝗚𝗦');

        conn.exec(command, (err, stream) => {
            if (err) {
                bot.sendMessage(chatId, `❌ Terjadi error saat eksekusi command`);
                return conn.end();
            }

            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ' + code + ' and signal ' + signal);
                bot.sendMessage(chatId, '𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗧𝗔𝗥𝗧 𝗪𝗜𝗡𝗚𝗦 𝗦𝗜𝗟𝗔𝗛𝗞𝗔𝗡 𝗖𝗘𝗞 𝗡𝗢𝗗𝗘 𝗔𝗡𝗗𝗔😁');
                conn.end();
            }).on('data', (data) => {
                stream.write('3\n');
                stream.write(`${token}\n`);
                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        bot.sendMessage(chatId, '❌ Katasandi atau IP tidak valid!');
    }).connect(connSettings);
});

// Handler untuk command /wings tanpa parameter
bot.onText(/^\/wings$/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `*Format salah!*\nPenggunaan: /wings ipvps,password,token\n\nContoh: /wings 192.168.1.1,password123,token_configuration_here`, { 
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
                [{ text: "HUBUNGI ADMIN", url: "https://t.me/Neneko20" }]
            ]
        }
    });
});


//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//INSTALL PANEL 2
bot.onText(/^(\.|\#|\/)installpanel2$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹2 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱𝘃𝗽𝘀,𝗱𝗼𝗺𝗮𝗶𝗻𝗽𝗻𝗹,𝗱𝗼𝗺𝗮𝗶𝗻𝗻𝗼𝗱𝗲,𝟭𝟲𝟬𝟬𝟬𝟬𝟬𝟬`);
  });

bot.onText(/\/installpanel2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const t = text.split(',');

  if (t.length < 3) {
    return bot.sendMessage(chatId, '𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹2 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱𝘃𝗽𝘀,𝗱𝗼𝗺𝗮𝗶𝗻𝗽𝗻𝗹,𝗱𝗼𝗺𝗮𝗶𝗻𝗻𝗼𝗱𝗲,𝗿𝗮𝗺𝘃𝗽𝘀 ( ᴄᴏɴᴛᴏʜ : 𝟾𝟶𝟶𝟶 = ʀᴀᴍ 𝟾');
  }

  const ipvps = t[0];
  const passwd = t[1];
  const subdomain = t[2];
  const domainnode = t[3];
  const ramvps = t[4];

  
  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };

  const password = generateRandomPassword();
  const command = 'bash <(curl -s https://pterodactyl-installer.se)';
  const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
  const conn = new Client();

  conn.on('ready', () => {
    bot.sendMessage(chatId, '𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗦𝗘𝗗𝗔𝗡𝗚 𝗕𝗘𝗥𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝟱-𝟭𝟬𝗠𝗘𝗡𝗜𝗧');
    
    conn.exec(command, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗻𝗷𝗮𝗹𝗮𝗻𝗸𝗮𝗻 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗶𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶.');
        conn.end();
        return;
      }

      stream.on('close', (code, signal) => {
        console.log(`Stream closed with code ${code} and signal ${signal}`);
        installWings(conn, domainnode, subdomain, password, ramvps);
      }).on('data', (data) => {
        handlePanelInstallationInput(data, stream, subdomain, password);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }).on('error', (err) => {
    // Tangani error jika koneksi gagal
    if (err.message.includes('All configured authentication methods failed')) {
      bot.sendMessage(chatId, 'Koneksi gagal: Kata sandi salah atau VPS tidak dapat diakses.');
    } else if (err.message.includes('connect ECONNREFUSED')) {
      bot.sendMessage(chatId, 'Koneksi gagal: VPS tidak bisa diakses atau mati.');
    } else {
      bot.sendMessage(chatId, `Koneksi gagal: ${err.message}`);
    }
    console.error('Connection Error: ', err.message);
  }).connect(connSettings);
  
  async function installWings(conn, domainnode, subdomain, password, ramvps) {
    bot.sendMessage(chatId, '𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗪𝗜𝗡𝗚𝗦 𝗦𝗘𝗗𝗔𝗡𝗚 𝗕𝗘𝗥𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝟱 𝗠𝗘𝗡𝗜𝗧');
    conn.exec(commandWings, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗻𝗷𝗮𝗹𝗮𝗻𝗸𝗮𝗻 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗶𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝘄𝗶𝗻𝗴𝘀.');
        conn.end();
        return;
      }
      
      stream.on('close', (code, signal) => {
        console.log(`Wings installation stream closed with code ${code} and signal ${signal}`);
        createNode(conn, domainnode, ramvps, subdomain, password);
      }).on('data', (data) => {
        handleWingsInstallationInput(data, stream, domainnode, subdomain);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }

  async function createNode(conn, domainnode, ramvps, subdomain, password) {
    const command = 'bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/Installerlex/refs/heads/main/install.sh)';
    bot.sendMessage(chatId, '𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗖𝗥𝗘𝗔𝗧𝗘 𝗡𝗢𝗗𝗘 & 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡');
    
    conn.exec(command, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗺𝗯𝘂𝗮𝘁 𝗻𝗼𝗱𝗲.');
        conn.end();
        return;
      }

      stream.on('close', (code, signal) => {
        console.log(`Node creation stream closed with code ${code} and ${signal} signal`);
        conn.end();
        sendPanelData(subdomain);
      }).on('data', (data) => {
        handleNodeCreationInput(data, stream, domainnode, ramvps);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }

  function sendPanelData(subdomain) {
    bot.sendMessage(chatId, `𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n\n𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: 𝗻𝗲𝗸𝗼𝗿𝗶\n𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗: 𝗻𝗲𝗸𝗼𝗿𝗶\n𝗟𝗢𝗚𝗜𝗡: ${subdomain}\n\n𝗡𝗼𝘁𝗲: 𝗦𝗲𝗺𝘂𝗮 𝗜𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝗧𝗲𝗹𝗮𝗵 𝗦𝗲𝗹𝗲𝘀𝗮𝗶. 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗰𝗿𝗲𝗮𝘁𝗲 𝗮𝗹𝗹𝗼𝗰𝗮𝘁𝗶𝗼𝗻 𝗱𝗶 𝗻𝗼𝗱𝗲 𝘆𝗮𝗻𝗴 𝗱𝗶𝗯𝘂𝗮𝘁 𝗼𝗹𝗲𝗵 𝗯𝗼𝘁 𝗱𝗮𝗻 𝗮𝗺𝗯𝗶𝗹 𝘁𝗼𝗸𝗲𝗻 𝗸𝗼𝗻𝗳𝗶𝗴𝘂𝗿𝗮𝘀𝗶, 𝗹𝗮𝗹𝘂 𝗸𝗲𝘁𝗶𝗸 /𝘄𝗶𝗻𝗴𝘀 𝗶𝗽𝘃𝗽𝘀,𝗽𝘄𝘃𝗽𝘀,(𝘁𝗼𝗸𝗲𝗻). \n𝗡𝗼𝘁𝗲: 𝗛𝗮𝗿𝗮𝗽 𝘁𝘂𝗻𝗴𝗴𝘂 𝟭-𝟱 𝗺𝗲𝗻𝗶𝘁 𝗮𝗴𝗮𝗿 𝘄𝗲𝗯 𝗯𝗶𝘀𝗮 𝗱𝗶𝗮𝗸𝘀𝗲𝘀.`);
  }

  function handlePanelInstallationInput(data, stream, subdomain, password) {
    if (data.toString().includes('Input')) {
      stream.write('0\n');
    }
    if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('Asia/Jakarta\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekorioffc@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekorioffc@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekori\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekori\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekori\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`nekori\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('yes\n');
        }
        if (data.toString().includes('Please read the Terms of Service')) {
            stream.write('A\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('1\n');
        }
    console.log('STDOUT: ' + data);
  }

  function handleWingsInstallationInput(data, stream, domainnode, subdomain) {
    if (data.toString().includes('Input')) {
      stream.write('1\n');
    }
    if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${domainnode}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekorioffc@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
    console.log('STDOUT: ' + data);
  }

  function handleNodeCreationInput(data, stream, domainnode, ramvps) {
    stream.write('4\n');
    stream.write('NEKORI\n');
    stream.write('NEKORI\n');
    stream.write(`${domainnode}\n`);
    stream.write('NEKORI\n');
    stream.write(`${ramvps}\n`);
    stream.write(`${ramvps}\n`);
    stream.write('1\n');
    console.log('STDOUT: ' + data);
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//HACKBACK PANEL
bot.onText(/^(\.|\#|\/)hackback$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /hackback 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱`);
  });
bot.onText(/\/hackback (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const t = text.split(',');
  if (t.length < 2) {
    return bot.sendMessage(chatId, '𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /hackback 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱,𝘁𝗼𝗸𝗲𝗻');
  }
  const ipvps = t[0];
  const passwd = t[1];

  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };
    const conn = new Client();
    const command = 'bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/Installerlex/refs/heads/main/install.sh)'
 
    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        bot.sendMessage(chatId,'PROSES HACK BACK PTERODACTYL')
        
        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ${code} and ${signal} signal');
         bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n\n𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: lexcz\n𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗: lexcz\n\n\n');
                conn.end();
            }).on('data', (data) => {
                stream.write('7\n');
                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        bot.sendMessage(chatId, 'Katasandi atau IP tidak valid');
    }).connect(connSettings);
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//INSTALL DEPEND
bot.onText(/\/installdepend (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const text = match[1];

    let t = text.split(',');
    if (t.length < 2) {
        return bot.sendMessage(chatId, `Format salah!\nPenggunaan: /installdepend ipvps,password`);
    }

    let ipvps = t[0];
    let passwd = t[1];
    

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = 'bash <(curl https://raw.githubusercontent.com/LeXcZxMoDz9/folderr/refs/heads/main/install.sh)';

    const conn = new Client();
    let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi

    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        bot.sendMessage(chatId, 'PROSES INSTALL DEPEND DIMULAI MOHON TUNGGU 1-2 MENIT KEDEPAN');

        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ' + code + ' and signal ' + signal);
                bot.sendMessage(chatId, '`SUKSES INSTALL DEPEND ADDON/NEBULA`');
                conn.end();
            }).on('data', (data) => {
                stream.write('11\n');
                stream.write('A\n');
                stream.write('Y\n');
                stream.write('Y\n');

                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        bot.sendMessage(chatId, 'Katasandi atau IP tidak valid');
    }).connect(connSettings);

    setTimeout(() => {
        if (isSuccess) {
            bot.sendMessage(chatId, '');
        }
    }, 60000); // 180000 ms = 3 menit
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//HACKBACK PANEL
bot.onText(/^(\.|\#|\/)hackback$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /hackback 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱`);
  });
bot.onText(/\/hackback (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const t = text.split(',');
  if (t.length < 2) {
    return bot.sendMessage(chatId, '𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /hackback 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱,𝘁𝗼𝗸𝗲𝗻');
  }
  const ipvps = t[0];
  const passwd = t[1];

  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };
    const conn = new Client();
    const command = 'bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/Installerlex/refs/heads/main/install.sh)'
 
    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        bot.sendMessage(chatId,'PROSES HACK BACK PTERODACTYL')
        
        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ${code} and ${signal} signal');
         bot.sendMessage(chatId, '𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n\n𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: lexcz\n𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗: lexcz\n\n\n');
                conn.end();
            }).on('data', (data) => {
                stream.write('7\n');
                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        bot.sendMessage(chatId, 'Katasandi atau IP tidak valid');
    }).connect(connSettings);
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// Gopay
bot.onText(/\/gopay/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, "gopay\nBelom Ada\nA/N Ga Ada\n\nSERTAKAN KIRIM PEMBUKTIAN\nTRANSFER KE OWNER,\nUNTUK MELANJUTKAN TRANSAKSI.", {
        'reply_markup' :{
            'inline_keyboard': [[{ 'text': 'CHANEL', 'url': 'https://t.me/nenekostore'},
            { 'text': 'OWNER', 'url': 'https://t.me/Neneko20'}]]
        }
    })
})
// qris
bot.onText(/\/qris/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendPhoto(chatId, "https://files.catbox.moe/do750c.jpg", {
        caption: "Qris\nNEKO STORE\n\nSERTAKAN KIRIM PEMBUKTIAN TRANSFER KE OWNER, UNTUK MELANJUTKAN TRANSAKSI.",
        'reply_markup': {
            'inline_keyboard': [
                [
                    { 'text': 'CHANEL', 'url': 'https://t.me/nenekostore' },
                    { 'text': 'OWNER', 'url': 'https://t.me/Neneko20' }
                ]
            ]
        }
    });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// Ovo
bot.onText(/\/ovo/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, "Ovo\nBlom Ada\nA/N Blom Ada\n\nSERTAKAN KIRIM PEMBUKTIAN\nTRANSFER KE OWNER,\nUNTUK MELANJUTKAN TRANSAKSI.", {
        'reply_markup' :{
            'inline_keyboard': [[{ 'text': 'CHANEL', 'url': 'https://t.me/nenekostore'},
            { 'text': 'OWNER', 'url': 'https://t.me/Neneko20'}]]
        }
    })
})
bot.onText(/^(\.|\#|\/)uninstallpanel$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝘂𝗻𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱`);
  });
bot.onText(/\/uninstallpanel (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const t = text.split(',');
  if (t.length < 2) {
    return bot.sendMessage(chatId, '𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝘂𝗻𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱,𝘁𝗼𝗸𝗲𝗻');
  }
  const ipvps = t[0];
  const passwd = t[1];

  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };
    const conn = new Client();
    const command = 'bash <(curl -s https://pterodactyl-installer.se)'
 
    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        bot.sendMessage(chatId,'PROSES UNINSTALL PTERODACTYL')
        
        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ${code} and ${signal} signal');
         bot.sendMessage(chatId, '𝗦𝗨𝗖𝗖𝗘𝗦 𝗨𝗡𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗣𝗧𝗘𝗥𝗢𝗗𝗔𝗖𝗧𝗬𝗟');
                conn.end();
            }).on('data', (data) => {
                stream.write('6\n');
                stream.write(`y\n`);
                stream.write('y\n');
                stream.write(`y\n`);
                stream.write('y\n');
                stream.write(`\n`);
                stream.write('\n')
                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        bot.sendMessage(chatId, 'Katasandi atau IP tidak valid');
    }).connect(connSettings);
});
bot.onText(/^(\.|\#|\/)installpanel$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹1 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱𝘃𝗽𝘀,𝗱𝗼𝗺𝗮𝗶𝗻𝗽𝗻𝗹,𝗱𝗼𝗺𝗮𝗶𝗻𝗻𝗼𝗱𝗲,𝟭𝟲𝟬𝟬𝟬𝟬𝟬𝟬`);
  });

bot.onText(/\/installpanel (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const t = text.split(',');

  if (t.length < 3) {
    return bot.sendMessage(chatId, '𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲l 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱𝘃𝗽𝘀,𝗱𝗼𝗺𝗮𝗶𝗻𝗽𝗻𝗹,𝗱𝗼𝗺𝗮𝗶𝗻𝗻𝗼𝗱𝗲,𝗿𝗮𝗺𝘃𝗽𝘀 ( ᴄᴏɴᴛᴏʜ : 𝟾𝟶𝟶𝟶 = ʀᴀᴍ 𝟾');
  }

  const ipvps = t[0];
  const passwd = t[1];
  const subdomain = t[2];
  const domainnode = t[3];
  const ramvps = t[4];

  
  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };

  const password = generateRandomPassword();
  const command = 'bash <(curl -s https://pterodactyl-installer.se)';
  const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
  const conn = new Client();

  conn.on('ready', () => {
    bot.sendMessage(chatId, '𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗦𝗘𝗗𝗔𝗡𝗚 𝗕𝗘𝗥𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝟱-𝟭𝟬𝗠𝗘𝗡𝗜𝗧');
    
    conn.exec(command, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗻𝗷𝗮𝗹𝗮𝗻𝗸𝗮𝗻 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗶𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶.');
        conn.end();
        return;
      }

      stream.on('close', (code, signal) => {
        console.log(`Stream closed with code ${code} and signal ${signal}`);
        installWings(conn, domainnode, subdomain, password, ramvps);
      }).on('data', (data) => {
        handlePanelInstallationInput(data, stream, subdomain, password);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }).on('error', (err) => {
    // Tangani error jika koneksi gagal
    if (err.message.includes('All configured authentication methods failed')) {
      bot.sendMessage(chatId, 'Koneksi gagal: Kata sandi salah atau VPS tidak dapat diakses.');
    } else if (err.message.includes('connect ECONNREFUSED')) {
      bot.sendMessage(chatId, 'Koneksi gagal: VPS tidak bisa diakses atau mati.');
    } else {
      bot.sendMessage(chatId, `Koneksi gagal: ${err.message}`);
    }
    console.error('Connection Error: ', err.message);
  }).connect(connSettings);
  
  async function installWings(conn, domainnode, subdomain, password, ramvps) {
    bot.sendMessage(chatId, '𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗪𝗜𝗡𝗚𝗦 𝗦𝗘𝗗𝗔𝗡𝗚 𝗕𝗘𝗥𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝟱 𝗠𝗘𝗡𝗜𝗧');
    conn.exec(commandWings, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗻𝗷𝗮𝗹𝗮𝗻𝗸𝗮𝗻 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗶𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝘄𝗶𝗻𝗴𝘀.');
        conn.end();
        return;
      }
      
      stream.on('close', (code, signal) => {
        console.log(`Wings installation stream closed with code ${code} and signal ${signal}`);
        createNode(conn, domainnode, ramvps, subdomain, password);
      }).on('data', (data) => {
        handleWingsInstallationInput(data, stream, domainnode, subdomain);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }

  async function createNode(conn, domainnode, ramvps, subdomain, password) {
    const command = 'bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/Installerlex/refs/heads/main/install.sh)';
    bot.sendMessage(chatId, '𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗖𝗥𝗘𝗔𝗧𝗘 𝗡𝗢𝗗𝗘 & 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡');
    
    conn.exec(command, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗺𝗯𝘂𝗮𝘁 𝗻𝗼𝗱𝗲.');
        conn.end();
        return;
      }

      stream.on('close', (code, signal) => {
        console.log(`Node creation stream closed with code ${code} and ${signal} signal`);
        conn.end();
        sendPanelData(subdomain);
      }).on('data', (data) => {
        handleNodeCreationInput(data, stream, domainnode, ramvps);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }

  function sendPanelData(subdomain) {
    bot.sendMessage(chatId, `𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n\n𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: 𝗻𝗲𝗸𝗼𝗿𝗶\n𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗: 𝗻𝗲𝗸𝗼𝗿𝗶\n𝗟𝗢𝗚𝗜𝗡: ${subdomain}\n\n𝗡𝗼𝘁𝗲: 𝗦𝗲𝗺𝘂𝗮 𝗜𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝗧𝗲𝗹𝗮𝗵 𝗦𝗲𝗹𝗲𝘀𝗮𝗶. 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗰𝗿𝗲𝗮𝘁𝗲 𝗮𝗹𝗹𝗼𝗰𝗮𝘁𝗶𝗼𝗻 𝗱𝗶 𝗻𝗼𝗱𝗲 𝘆𝗮𝗻𝗴 𝗱𝗶𝗯𝘂𝗮𝘁 𝗼𝗹𝗲𝗵 𝗯𝗼𝘁 𝗱𝗮𝗻 𝗮𝗺𝗯𝗶𝗹 𝘁𝗼𝗸𝗲𝗻 𝗸𝗼𝗻𝗳𝗶𝗴𝘂𝗿𝗮𝘀𝗶, 𝗹𝗮𝗹𝘂 𝗸𝗲𝘁𝗶𝗸 /𝘄𝗶𝗻𝗴𝘀 𝗶𝗽𝘃𝗽𝘀,𝗽𝘄𝘃𝗽𝘀,(𝘁𝗼𝗸𝗲𝗻). \n𝗡𝗼𝘁𝗲: 𝗛𝗮𝗿𝗮𝗽 𝘁𝘂𝗻𝗴𝗴𝘂 𝟭-𝟱 𝗺𝗲𝗻𝗶𝘁 𝗮𝗴𝗮𝗿 𝘄𝗲𝗯 𝗯𝗶𝘀𝗮 𝗱𝗶𝗮𝗸𝘀𝗲𝘀.`);
  }

  function handlePanelInstallationInput(data, stream, subdomain, password) {
    if (data.toString().includes('Input')) {
      stream.write('0\n');
    }
    if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('Asia/Jakarta\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekorioffc@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekorioffc@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekori\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekori\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekori\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`nekori\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('yes\n');
        }
        if (data.toString().includes('Please read the Terms of Service')) {
            stream.write('Y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('1\n');
        }
    console.log('STDOUT: ' + data);
  }

  function handleWingsInstallationInput(data, stream, domainnode, subdomain) {
    if (data.toString().includes('Input')) {
      stream.write('1\n');
    }
    if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write(`${password}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write(`${domainnode}\n`);
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('nekorioffc@gmail.com\n');
        }
        if (data.toString().includes('Input')) {
            stream.write('y\n');
        }
    console.log('STDOUT: ' + data);
  }

  function handleNodeCreationInput(data, stream, domainnode, ramvps) {
    stream.write('4\n');
    stream.write('NEKORI\n');
    stream.write('NEKORI\n');
    stream.write(`${domainnode}\n`);
    stream.write('NEKORI\n');
    stream.write(`${ramvps}\n`);
    stream.write(`${ramvps}\n`);
    stream.write('1\n');
    console.log('STDOUT: ' + data);
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// cekid
bot.onText(/\/cekid/, async (msg) => {
  const chatId = msg.chat.id;
  const isReply = !!msg.reply_to_message;
  const target = isReply ? msg.reply_to_message.from : msg.from;

  const firstName = target.first_name || '';
  const lastName = target.last_name || '';
  const username = target.username ? '@' + target.username : 'Tidak ada';
  const userId = target.id;

  const caption = `
<b>👤 Info Pengguna</b>
├ <b>Nama:</b> ${firstName} ${lastName}
├ <b>Username:</b> ${username}
└ <b>ID:</b> <code>${userId}</code>
  `;

  try {
    const userProfilePhotos = await bot.getUserProfilePhotos(userId, { limit: 1 });

    if (userProfilePhotos.total_count === 0) throw new Error("No profile photo");

    const fileId = userProfilePhotos.photos[0][0].file_id;

    await bot.sendPhoto(chatId, fileId, {
      caption,
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: `${firstName} ${lastName}`,
              url: `tg://user?id=${userId}`
            }
          ]
        ]
      }
    });
  } catch (err) {
    await bot.sendMessage(chatId, caption, {
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id
    });
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delprem
bot.onText(/\/delprem (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1];
  if (msg.from.id.toString() === owner) {
    const index = premiumUsers.indexOf(userId);
    if (index !== -1) {
      premiumUsers.splice(index, 1);
      fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
      bot.sendMessage(
        chatId,
        `User ${userId} MAMPUS KAU DI DELPREM BNGST BABI.`
      );
    } else {
      bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
    }
  } else {
    bot.sendMessage(chatId, "Only the owner can perform this action.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1];

  if (msg.from.id.toString() === owner) {
    if (!adminUsers.includes(userId)) {
      adminUsers.push(userId);
      fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
      bot.sendMessage(
        chatId,
        `User ${userId} LEBIH KELAZZ JADI OWNER BOT NEKO.`
      );
    } else {
      bot.sendMessage(chatId, `User ${userId} is already an admin user.`);
    }
  } else {
    bot.sendMessage(chatId, "Only the owner can perform this action.");
  }
});
// panel
bot.onText(/\/panel/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '6898114344'; // Ganti dengan ID pemilik bot 
    const text12 = `*Hi @${sender} 👋*
    
𝗖𝗔𝗥𝗔 𝗕𝗜𝗞𝗜𝗡 𝗣𝗔𝗡𝗘𝗟 𝗕𝗬 𝗡𝗘𝗡𝗘𝗞𝗢

𝗖𝗔𝗥𝗔 𝗔𝗗𝗗 𝗨𝗦𝗘𝗥 𝗣𝗔𝗡𝗘𝗟 :
𝗿𝗮𝗺 𝘂𝘀𝗲𝗿𝘀,𝗜𝗱

𝗰𝗼𝗻𝘁𝗼𝗵 : /𝟭𝗴𝗯 𝗰𝗲𝗹𝗹𝗼,𝟭𝟯𝟰𝟰𝟱𝟱𝘅𝘅𝘅

𝗕𝘂𝘆 𝗣𝗿𝗲𝗺? 𝗕𝘂𝘆 𝗩𝗽𝘀? 𝗕𝘂𝘆 𝗔𝗱𝗺𝗶𝗻𝗣&𝗣𝘁 𝗣𝗮𝗻𝗲𝗹? 𝗕𝘂𝘆 𝗦𝗰? 𝗣𝘃 (@Neneko20)`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ Buy Panel', url: 'https://t.me/Neneko20/buy_panel' }, { text: '👤 Buy Admin', url: 'https://t.me/Neneko20/buyadminp & ptpanel' }],
                [{ text: '🇲🇨 Buy Vps', url: 'https://t.me/Neneko20/buyvps' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1];

  if (msg.from.id.toString() === owner) {
    const index = adminUsers.indexOf(userId);
    if (index !== -1) {
      adminUsers.splice(index, 1);
      fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
      bot.sendMessage(chatId, `User ${userId} MAMPUS KAU BABI DI DELL.`);
    } else {
      bot.sendMessage(chatId, `User ${userId} is not an admin user.`);
    }
  } else {
    bot.sendMessage(chatId, "Only the owner can perform this action.");
  }
});

function generatePassword(length = 12) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let pass = ''
  for (let i = 0; i < length; i++) {
    pass += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return pass
}

function buatCommandPanel(gb, cpu) {
  bot.onText(new RegExp(`\\/${gb === 0 ? 'unli' : gb + 'gb'} (.+)`), async (msg, match) => {
    const chatId = msg.chat.id
    const text = match[1]
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile))
    const isPremium = premiumUsers.includes(String(msg.from.id))

    if (!isPremium) {
      return bot.sendMessage(chatId, "DI ADDPREM DULU KONTOL,MINTA AMA NEKO SANA...", {
        reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/Neneko20" }],
          ],
        },
      })
    }

    const t = text.split(",")
    if (t.length < 2) {
      return bot.sendMessage(chatId, `Invalid format. Usage: /${gb === 0 ? 'unli' : gb + 'gb'} namapanel,idtele`)
    }

    const username = t[0]
    const u = t[1]
    const name = username
    const egg = settings.eggs
    const loc = settings.loc
    const memo = gb === 0 ? 0 : String(gb * 1024)
    const disk = gb === 0 ? 0 : String(gb * 1024)
    const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}'
    const email = `${username}@gmail.com`
    const password = `${username}${generatePassword(4)}`

    const now = new Date();
    const day = String(now.getDate()).padStart(2, "0");
    const month = now.toLocaleDateString("id-ID", { month: "long" });
    const year = now.getFullYear();
    const dateStr = `${day}-${month}-${year}`;

    let user
    let server

    try {
      const response = await fetch(`${domain}/api/application/users`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
        body: JSON.stringify({
          email: email,
          username: username,
          first_name: username,
          last_name: username,
          language: "en",
          password: password,
        }),
      })

      const data = await response.json()
      if (!response.ok) {
        return bot.sendMessage(chatId, `⚠️ Gagal membuat user: ${JSON.stringify(data.errors || data)}`)
      }

      user = data.attributes

      const response2 = await fetch(`${domain}/api/application/servers`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
        body: JSON.stringify({
          name: name,
          description: `${dateStr}`,
          user: user.id,
          egg: parseInt(egg),
          docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
          startup: spc,
          environment: {
            INST: "npm",
            USER_UPLOAD: "0",
            AUTO_UPDATE: "0",
            CMD_RUN: "npm start",
          },
          limits: {
            memory: memo,
            swap: 0,
            disk: disk,
            io: 500,
            cpu: gb === 0 ? 0 : cpu,
          },
          feature_limits: {
            databases: 5,
            backups: 5,
            allocations: 1,
          },
          deploy: {
            locations: [parseInt(loc)],
            dedicated_ip: false,
            port_range: [],
          },
        }),
      })

      const data2 = await response2.json()
      if (!response2.ok) {
        return bot.sendMessage(chatId, `⚠️ Gagal membuat server: ${JSON.stringify(data2.errors || data2)}`)
      }

      server = data2.attributes

    } catch (error) {
      return bot.sendMessage(chatId, `⚠️ Terjadi error: ${error.message}`)
    }

    if (user && server) {
      bot.sendMessage(chatId, `✅ PANEL ${gb === 0 ? 'UNLI' : gb + 'GB'} BERHASIL DI BUAT
🆔 ID User: ${user.id}
🆔 ID Server: ${server.id}`)

      if (settings.pp) {
        bot.sendAnimation(u, settings.pp, {
          caption: `Hai @${u}

𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗘𝗧𝗔𝗜𝗟 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 📦
• 👤 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 🔐 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : <code>${password}</code>
• 🔗 𝗟𝗶𝗻𝗸 𝗟𝗼𝗴𝗶𝗻 : ${domain}

🌐 𝗦𝗽𝗲𝘀𝗶𝗳𝗶𝗸𝗮𝘀𝗶 𝗦𝗲𝗿𝘃𝗲𝗿
• 𝗥𝗮𝗺 : ${server.limits.memory === 0 ? "Unlimited" : `${server.limits.memory / 1024} GB`}
• 𝗗𝗶𝘀𝗸 : ${server.limits.disk === 0 ? "Unlimited" : `${server.limits.disk / 1024} GB`}
• 𝗖𝗣𝗨 : ${server.limits.cpu === 0 ? "Unlimited" : `${server.limits.cpu}%`}

Syarat & Ketentuan :
• Expired panel 1 bulan
• Simpan data ini sebaik mungkin
• Garansi pembelian 15 hari (1× replace)
• Claim garansi wajib membawa bukti chat pembelian`,
          parse_mode: "HTML"
        })
        bot.sendMessage(chatId, `Data panel ${gb === 0 ? 'UNLI' : gb + 'GB'} berhasil dikirim ke ID Telegram yang dimaksud.`)
      }
    } else {
      bot.sendMessage(chatId, `⚠️ Gagal membuat data panel ${gb === 0 ? 'UNLI' : gb + 'GB'}. Silakan coba lagi.`)
    }
  })
}

buatCommandPanel(1, 40)    // /1gb
buatCommandPanel(2, 60)    // /2gb  
buatCommandPanel(3, 80)    // /3gb
buatCommandPanel(4, 100)   // /4gb
buatCommandPanel(5, 120)   // /5gb
buatCommandPanel(6, 140)   // /6gb
buatCommandPanel(7, 160)   // /7gb
buatCommandPanel(8, 180)   // /8gb
buatCommandPanel(9, 200)   // /9gb
buatCommandPanel(10, 220)  // /10gb
buatCommandPanel(0, 0)     // /unli
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/delsrv (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const srv = match[1].trim();

  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));

  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "Perintah hanya untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Hubungi Admin", url: "https://t.me/Neneko20" }],
          ],
        },
      }
    );
    return;
  }

  if (!srv) {
    bot.sendMessage(
      chatId,
      "Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1234"
    );
    return;
  }

  try {
    let f = await fetch(domain + "/api/application/servers/" + srv, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    let res = f.ok ? { errors: null } : await f.json();

    if (res.errors) {
      bot.sendMessage(chatId, "SERVER TIDAK ADA");
    } else {
      bot.sendMessage(chatId, "SUCCESFULLY DELETE SERVER");
    }
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan saat menghapus server.");
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// cadmin
bot.onText(/\/cadmin (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        return bot.sendMessage(chatId, "BAPAK KAU MAU CREATE ADMIN, ADDOWNER DULU AMA NEKO SANA..", {
            reply_markup: {
                inline_keyboard: [
                    [{ text: "HUBUNGI ADMIN", url: "https://t.me/Neneko20" }]
                ]
            }
        });
    }

    const text = match[1];
    const parts = text.split(",");

    if (parts.length < 2) {
        return bot.sendMessage(chatId, "Format salah! Contoh: /cadmin namapanel,123456789");
    }

    const panelName = parts[0].trim();
    const telegramId = parts[1].trim();
    
    // Generate password: nama + 4 karakter random
    const randomChars = generatePassword(4);
    const password = panelName + randomChars;

    try {
        const response = await fetch(`${domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`
            },
            body: JSON.stringify({
                email: `${panelName}@gmail.com`,
                username: panelName,
                first_name: panelName,
                last_name: "Admin",
                language: "en",
                root_admin: true,
                password: password
            })
        });

        const data = await response.json();

        if (!response.ok) {
            return bot.sendMessage(chatId, `❌ Gagal membuat admin: ${JSON.stringify(data.errors || data)}`);
        }

        const user = data.attributes;
        
        bot.sendMessage(chatId, `✅ Admin Panel Berhasil Dibuat!\n👤 Username: ${user.username}\n🆔 ID: ${user.id}\n📧 Email: ${user.email}\n\n📩 Data telah dikirim ke ID: ${telegramId}`);

        // Kirim detail ke user (pemilik ID Telegram)
        bot.sendMessage(telegramId, 
`┏━⬣❏「 INFO DATA ADMIN PANEL 」❏
│➥  Login : ${domain}
│➥  Username :  <code>${user.username}</code>
│➥  Password : <code>${password}</code> 
┗━━━━━━━━━⬣
│ Rules : 
│• Jangan Curi Sc
│• Jangan Buka Panel Orang
│• Jangan Ddos Server
│• Kalo jualan sensor domainnya
│• Jangan Bagi² Panel Free !!
│• Jangan bagi bagi panel free !! ngelanggar? maklu matyy
┗━━━━━━━━━━━━━━━━━━⬣
THANKS FOR NEKO`,
            { parse_mode: "HTML" }
        );

    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat admin.");
    }
});

bot.onText(/^\/cadmin$/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, "Format salah! Contoh: /cadmin namapanel,123456789");
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/changepass\s+(\d+)\s+(.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id.toString();
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id)) || senderId === owner;

  if (!isAdmin) {
    return bot.sendMessage(chatId, "❌ FITUR KHUSUS OWNER DAN ADMIN!");
  }

  const userId = match[1];
  const newPass = match[2];

  try {
    const getUser = await fetch(`${domain}/api/application/users/${userId}`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${plta}`,
        "Accept": "application/json"
      }
    });

    if (!getUser.ok) {
      return bot.sendMessage(chatId, `❌ User dengan ID ${userId} tidak ditemukan.`);
    }

    const userData = await getUser.json();
    const u = userData.attributes;

    const updateUser = await fetch(`${domain}/api/application/users/${userId}`, {
      method: "PATCH",
      headers: {
        "Authorization": `Bearer ${plta}`,
        "Accept": "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email: u.email,
        username: u.username,
        first_name: u.first_name,
        last_name: u.last_name,
        language: u.language,
        password: newPass
      })
    });

    if (!updateUser.ok) {
      const errorData = await updateUser.json();
      return bot.sendMessage(chatId, `❌ Gagal mengganti password: ${JSON.stringify(errorData.errors || errorData, null, 2)}`);
    }

    bot.sendMessage(chatId, `✅ Password **user ID ${userId}** berhasil diganti menjadi:\n\`\`\`${newPass}\`\`\``, {
      parse_mode: "Markdown"
    });

  } catch (err) {
    console.error('Error changing password:', err);
    bot.sendMessage(chatId, `❌ Gagal mengganti password.\n\n\`\`\`${err.message}\`\`\``, {
      parse_mode: "Markdown"
    });
  }
});

// Handler untuk command /csubdo 
bot.onText(/\/csubdo (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (userId !== owner) {
        return bot.sendMessage(
            chatId,
            "BAPAK KAU MAU CREATE SUBDOMAIN, ADDOWNER DULU AMA NEKO SANA..",
            {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "Hubungi Owner", url: "https://t.me/Neneko20" }],
                    ],
                },
            }
        );
    }

    const text = match[1].split(' ');
    
    if (text.length < 2) {
        return bot.sendMessage(chatId, "❌ FORMAT SALAH!\n\nGunakan: /csubdo <subdomain> <ip>\n\nContoh: /csubdo mysubdomain 192.168.1.1");
    }
    
    const subdomain = text[0];
    const ip = text[1];
  
    if (!isValidSubdomain(subdomain)) {
        return bot.sendMessage(chatId, '❌ SUBDOMAIN TIDAK VALID!\n\nSubdomain hanya boleh mengandung huruf, angka, dan tanda minus (-), tidak boleh diawali/diakhiri dengan minus, maksimal 63 karakter.');
    }
    
    if (!isValidIP(ip)) {
        return bot.sendMessage(chatId, '❌ IP ADDRESS TIDAK VALID!\n\nPastikan format IP address benar (contoh: 192.168.1.1)');
    }
    
    const processingMsg = await bot.sendMessage(chatId, '⏳ Sedang membuat subdomain...');
    
    try {
        // Gunakan konfigurasi dari settings.cloudflare
        const response = await csubdo(subdomain, ip);
        
        await bot.editMessageText(response.message, {
            chat_id: chatId,
            message_id: processingMsg.message_id
        });
        
    } catch (error) {
        await bot.editMessageText('❌ TERJADI KESALAHAN SISTEM!\n\nSilakan coba lagi beberapa saat.', {
            chat_id: chatId,
            message_id: processingMsg.message_id
        });
    }
});

// Handler untuk command /csubdo tanpa parameter
bot.onText(/^\/csubdo$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (userId !== owner) {
        return bot.sendMessage(
            chatId,
            "❌ Perintah ini hanya untuk Owner bot!",
            {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "Hubungi Owner", url: "https://t.me/Neneko20" }],
                    ],
                },
            }
        );
    }

    bot.sendMessage(chatId, "❌ FORMAT SALAH!\n\nGunakan: /csubdo <subdomain> <ip>\n\nContoh: /csubdo mysubdomain 192.168.1.1");
});

//HANDLER SALAH
bot.onText(/^\/changepass$/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "❌ Format salah!\n\nContoh: `/changepass 123 password_baru`\n\nKeterangan:\n- `123` = ID user di panel\n- `password_baru` = password baru yang diinginkan", {
    parse_mode: "Markdown"
  });
});

bot.onText(/^\/changepass\s+(\d+)$/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "❌ Format salah!\n\nContoh: `/changepass 123 password_baru`\n\nAnda lupa menulis password baru.", {
    parse_mode: "Markdown"
  });
});

bot.onText(/\/setadp (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  // Cek apakah user adalah owner
  if (userId !== owner) {
    return bot.sendMessage(
      chatId,
      "❌ Perintah ini hanya untuk Owner bot!",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Hubungi Owner", url: "https://t.me/Neneko20" }],
          ],
        },
      }
    );
  }

  const text = match[1];
  const params = text.split(',');

  // Validasi parameter
  if (params.length < 3) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\n\n" +
      "Penggunaan: `/setadp domain,plta,pltc`\n\n" +
      "Contoh:\n" +
      "`/setadp https://example.com,ptla_*********,ptlc_***********`",
      { parse_mode: "Markdown" }
    );
  }

  const newDomain = params[0].trim();
  const newPlta = params[1].trim();
  const newPltc = params[2].trim();

  // Validasi domain
  if (!newDomain.startsWith('http://') && !newDomain.startsWith('https://')) {
    return bot.sendMessage(
      chatId,
      "❌ Domain harus dimulai dengan http:// atau https://"
    );
  }

  // Validasi plta dan pltc format (basic validation)
  if (!newPlta.startsWith('ptla_') || !newPltc.startsWith('ptlc_')) {
    return bot.sendMessage(
      chatId,
      "❌ Format plta atau pltc tidak valid. plta harus dimulai dengan 'ptla_' dan pltc dengan 'ptlc_'"
    );
  }

  try {
    // Generate unique key untuk data sementara
    const tempKey = `setadp_${chatId}_${Date.now()}`;
    
    // Simpan data sementara
    global.tempSettingsData[tempKey] = {
      domain: newDomain,
      plta: newPlta,
      pltc: newPltc,
      timestamp: Date.now()
    };

    // Clean up old temporary data (older than 10 minutes)
    cleanupTempData();

    // Konfirmasi sebelum mengubah
    const confirmKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "✅ YA, UPDATE SETTINGS", 
              callback_data: `setadp_confirm_${tempKey}` 
            },
            { 
              text: "❌ BATAL", 
              callback_data: `setadp_cancel_${tempKey}` 
            }
          ]
        ]
      }
    };

    const confirmMessage = await bot.sendMessage(
      chatId,
      `🚨 **KONFIRMASI UPDATE SETTINGS** 🚨\n\n` +
      `**Data yang akan diubah:**\n` +
      `• Domain: \`${newDomain}\`\n` +
      `• PLTA: \`${newPlta.substring(0, 10)}...\`\n` +
      `• PLTC: \`${newPltc.substring(0, 10)}...\`\n\n` +
      `**PERINGATAN:**\n` +
      `• Bot akan menggunakan credentials baru\n` +
      `• Pastikan credentials valid\n` +
      `• Perubahan akan langsung berlaku\n\n` +
      `Klik ✅ YA untuk melanjutkan atau ❌ BATAL untuk membatalkan.`,
      { 
        parse_mode: "Markdown",
        reply_markup: confirmKeyboard.reply_markup 
      }
    );

  } catch (error) {
    console.error('Error in /setadp command:', error);
    bot.sendMessage(
      chatId,
      `❌ Terjadi kesalahan:\n\`\`\`${error.message}\`\`\``,
      { parse_mode: "Markdown" }
    );
  }
});

// Handler untuk callback query konfirmasi setadp (FIXED)
bot.on("callback_query", async (callbackQuery) => {
  const callbackData = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const userId = callbackQuery.from.id.toString();

  try {
    // Handle setadp confirmation
    if (callbackData.startsWith("setadp_confirm_")) {
      await bot.answerCallbackQuery(callbackQuery.id, { text: "Mengupdate settings..." });
      
      // Extract temp key dari callback data
      const tempKey = callbackData.replace("setadp_confirm_", "");
      
      // Cek apakah user adalah owner
      if (userId !== owner) {
        await bot.editMessageText("❌ Hanya owner yang dapat melakukan aksi ini.", {
          chat_id: chatId,
          message_id: messageId
        });
        return;
      }

      // Ambil data dari temporary storage
      if (!global.tempSettingsData[tempKey]) {
        await bot.editMessageText("❌ Data konfirmasi tidak ditemukan atau sudah kadaluarsa. Silakan ulangi perintah /setadp.", {
          chat_id: chatId,
          message_id: messageId
        });
        return;
      }

      const { domain: newDomain, plta: newPlta, pltc: newPltc } = global.tempSettingsData[tempKey];
      
      // Hapus data sementara
      delete global.tempSettingsData[tempKey];

      await bot.editMessageText("🔄 Mengupdate settings...", {
        chat_id: chatId,
        message_id: messageId
      });

      // Eksekusi update settings
      try {
        updateSettings(newDomain, newPlta, newPltc);

        const successMessage = 
          `✅ **SETTINGS BERHASIL DIUPDATE**\n\n` +
          `**Data baru:**\n` +
          `• Domain: \`${newDomain}\`\n` +
          `• PLTA: \`${newPlta.substring(0, 15)}...\`\n` +
          `• PLTC: \`${newPltc.substring(0, 15)}...\`\n\n` +
          `Settings telah diperbarui dan bot sekarang menggunakan credentials baru.`;

        await bot.editMessageText(successMessage, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown"
        });

      } catch (updateError) {
        throw new Error(`Gagal update settings: ${updateError.message}`);
      }

    } 
    // Handle setadp cancellation
    else if (callbackData.startsWith("setadp_cancel_")) {
      await bot.answerCallbackQuery(callbackQuery.id, { text: "Dibatalkan" });
      
      // Extract temp key dari callback data
      const tempKey = callbackData.replace("setadp_cancel_", "");
      
      // Hapus data sementara
      if (global.tempSettingsData[tempKey]) {
        delete global.tempSettingsData[tempKey];
      }
      
      await bot.editMessageText("❌ Update settings dibatalkan.", {
        chat_id: chatId,
        message_id: messageId
      });
    }
  } catch (error) {
    console.error('Error in setadp callback:', error);
    await bot.editMessageText(
      `❌ Gagal mengupdate settings:\n\`\`\`${error.message}\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown"
      }
    );
  }
});

// Fungsi untuk membersihkan data temporary yang sudah kadaluarsa
function cleanupTempData() {
  const now = Date.now();
  const tenMinutes = 10 * 60 * 1000; // 10 menit dalam milidetik
  
  for (const key in global.tempSettingsData) {
    if (global.tempSettingsData[key].timestamp && (now - global.tempSettingsData[key].timestamp) > tenMinutes) {
      delete global.tempSettingsData[key];
    }
  }
}

// Handler untuk command /setadp tanpa parameter
bot.onText(/^\/setadp$/, (msg) => {
  const chatId = msg.chat.id;
  
  bot.sendMessage(
    chatId,
    "❌ Format salah!\n\n" +
    "**Penggunaan:** `/setadp domain,plta,pltc`\n\n" +
    "**Contoh:**\n" +
    "`/setadp https://example.com,ptla_*********,ptlc_***********`\n\n" +
    "**Keterangan:**\n" +
    "• `domain` - Domain panel (contoh: https://panel.example.com)\n" +
    "• `plta` - Application API Key\n" +
    "• `pltc` - Client API Key",
    { parse_mode: "Markdown" }
  );
});

// Handler untuk menampilkan settings saat ini
bot.onText(/\/showadp/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  // Cek apakah user adalah owner
  if (userId !== owner) {
    return bot.sendMessage(
      chatId,
      "❌ Perintah ini hanya untuk Owner bot!",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Hubungi Owner", url: "https://t.me/Neneko20" }],
          ],
        },
      }
    );
  }

  try {
    const currentSettings = require('./settings');
    
    const settingsInfo = 
      `🔧 **CURRENT SETTINGS**\n\n` +
      `**Domain:** \`${currentSettings.domain}\`\n` +
      `**PLTA:** \`${currentSettings.plta}\`\n` +
      `**PLTC:** \`${currentSettings.pltc}\`\n` +
      `**Location:** \`${currentSettings.loc}\`\n` +
      `**Eggs:** \`${currentSettings.eggs}\`\n\n` +
      `Gunakan /setadp untuk mengubah settings.`;

    bot.sendMessage(chatId, settingsInfo, { parse_mode: "Markdown" });

  } catch (error) {
    bot.sendMessage(
      chatId,
      `❌ Gagal membaca settings:\n\`\`\`${error.message}\`\`\``,
      { parse_mode: "Markdown" }
    );
  }
});

bot.onText(/\/dellall/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  if (userId !== owner) {
    return bot.sendMessage(
      chatId,
      "❌ Perintah ini hanya untuk Owner bot!",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Hubungi Owner", url: "https://t.me/Neneko20" }],
          ],
        },
      }
    );
  }

  try {
    bot.sendMessage(chatId, "🔄 Memulai proses DELL ALL...\n⚠️ **PERINGATAN**: Ini akan menghapus SEMUA user dan server kecuali user ID 1!");

    // Konfirmasi sebelum melanjutkan
    const confirmKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ YA, LANJUTKAN", callback_data: "dellall_confirm" }],
          [{ text: "❌ BATAL", callback_data: "dellall_cancel" }]
        ]
      }
    };

    const confirmMessage = await bot.sendMessage(
      chatId, 
      "🚨 **KONFIRMASI DELL ALL** 🚨\n\n" +
      "Anda akan menghapus:\n" +
      "• SEMUA server yang ada\n" +
      "• SEMUA user kecuali user ID 1\n\n" +
      "Tindakan ini **TIDAK DAPAT DIBATALKAN**!\n\n" +
      "Klik ✅ YA untuk melanjutkan atau ❌ BATAL untuk membatalkan.",
      confirmKeyboard
    );

    // Handle callback query untuk konfirmasi
    bot.once("callback_query", async (callbackQuery) => {
      const callbackData = callbackQuery.data;
      const callbackChatId = callbackQuery.message.chat.id;
      const callbackMessageId = callbackQuery.message.message_id;

      if (callbackData === "dellall_confirm") {
        await bot.answerCallbackQuery(callbackQuery.id, { text: "Memulai DELL ALL..." });
        await bot.editMessageText("🔄 Memulai DELL ALL...", {
          chat_id: callbackChatId,
          message_id: callbackMessageId
        });

        await executeClearAll(callbackChatId);

      } else if (callbackData === "dellall_cancel") {
        await bot.answerCallbackQuery(callbackQuery.id, { text: "Dibatalkan" });
        await bot.editMessageText("❌ DELL ALL dibatalkan.", {
          chat_id: callbackChatId,
          message_id: callbackMessageId
        });
      }
    });

  } catch (error) {
    console.error('Error in /dellall command:', error);
    bot.sendMessage(
      chatId,
      `❌ Terjadi kesalahan:\n\`\`\`${error.message}\`\`\``,
      { parse_mode: "Markdown" }
    );
  }
});

async function executeClearAll(chatId) {
  try {
    let deletedServers = [];
    let deletedUsers = [];

    // Ambil semua server
    let servers = [];
    let page = 1;
    let hasMorePages = true;

    while (hasMorePages) {
      const response = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Gagal mengambil data server: ${response.status}`);
      }

      const data = await response.json();
      servers = servers.concat(data.data);

      hasMorePages = data.meta.pagination.current_page < data.meta.pagination.total_pages;
      page++;
    }

    // Hapus semua server
    for (const server of servers) {
      const serverId = server.attributes.id;
      const serverName = server.attributes.name;

      try {
        const deleteResponse = await fetch(`${domain}/api/application/servers/${serverId}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${plta}`,
          },
        });

        if (deleteResponse.ok) {
          deletedServers.push({
            id: serverId,
            name: serverName
          });
        }
      } catch (error) {
        console.error(`Error deleting server ${serverId}:`, error);
      }
    }

    // Ambil semua users
    let users = [];
    page = 1;
    hasMorePages = true;

    while (hasMorePages) {
      const response = await fetch(`${domain}/api/application/users?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Gagal mengambil data user: ${response.status}`);
      }

      const data = await response.json();
      users = users.concat(data.data);

      hasMorePages = data.meta.pagination.current_page < data.meta.pagination.total_pages;
      page++;
    }

    // Hapus semua users kecuali ID 1
    for (const user of users) {
      const userId = user.attributes.id;
      const username = user.attributes.username;
      
      // Skip user dengan ID 1
      if (userId === 1) continue;
      
      try {
        const deleteResponse = await fetch(`${domain}/api/application/users/${userId}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${plta}`,
          },
        });

        if (deleteResponse.ok) {
          deletedUsers.push({
            id: userId,
            username: username
          });
        }
      } catch (error) {
        console.error(`Error deleting user ${userId}:`, error);
      }
    }

    // Buat laporan
    let report = `✅ **DELL ALL SELESAI**\n\n`;

    report += `🗑️ **Server yang dihapus:** ${deletedServers.length}\n`;
    if (deletedServers.length > 0) {
      deletedServers.forEach(server => {
        report += `└ ID: ${server.id} | ${server.name}\n`;
      });
    } else {
      report += `└ Tidak ada server yang dihapus\n`;
    }

    report += `\n👤 **User yang dihapus:** ${deletedUsers.length}\n`;
    if (deletedUsers.length > 0) {
      deletedUsers.forEach(user => {
        report += `└ ID: ${user.id} | ${user.username}\n`;
      });
    } else {
      report += `└ Tidak ada user yang dihapus\n`;
    }

    report += `\n✅ **User yang tersisa:** User ID 1\n`;
    report += `\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;

    bot.sendMessage(chatId, report);

  } catch (error) {
    console.error('Error in executeDellAll:', error);
    bot.sendMessage(
      chatId,
      `❌ Terjadi kesalahan saat melakukan DELL ALL:\n\`\`\`${error.message}\`\`\``,
      { parse_mode: "Markdown" }
    );
  }
}

bot.onText(/\/clear/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  if (userId !== owner) {
    return bot.sendMessage(
      chatId,
      "❌ Perintah ini hanya untuk Owner bot!",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Hubungi Owner", url: "https://t.me/Neneko20" }],
          ],
        },
      }
    );
  }

  try {
    bot.sendMessage(chatId, "🔄 Memulai proses pembersihan...");

    let servers = [];
    let page = 1;
    let hasMorePages = true;

    while (hasMorePages) {
      const response = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Gagal mengambil data server: ${response.status}`);
      }

      const data = await response.json();
      servers = servers.concat(data.data);

      hasMorePages = data.meta.pagination.current_page < data.meta.pagination.total_pages;
      page++;
    }

    let users = [];
    page = 1;
    hasMorePages = true;

    while (hasMorePages) {
      const response = await fetch(`${domain}/api/application/users?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Gagal mengambil data user: ${response.status}`);
      }

      const data = await response.json();
      users = users.concat(data.data);

      hasMorePages = data.meta.pagination.current_page < data.meta.pagination.total_pages;
      page++;
    }

    const deletedServers = [];
    const deletedUsers = [];
    const userServerCount = {};

    servers.forEach(server => {
      const userId = server.attributes.user;
      userServerCount[userId] = (userServerCount[userId] || 0) + 1;
    });

     for (const server of servers) {
      const serverId = server.attributes.id;
      const serverName = server.attributes.name;
      const serverUserId = server.attributes.user;

      try {
        const resourceResponse = await fetch(
          `${domain}/api/client/servers/${server.attributes.uuid.split("-")[0]}/resources`,
          {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${pltc}`,
            },
          }
        );

        let isOffline = true;
        if (resourceResponse.ok) {
          const resourceData = await resourceResponse.json();
          isOffline = resourceData.attributes.current_state === "offline";
        }

        if (isOffline) {
          const deleteResponse = await fetch(`${domain}/api/application/servers/${serverId}`, {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${plta}`,
            },
          });

          if (deleteResponse.ok) {
            deletedServers.push({
              id: serverId,
              name: serverName,
              user: serverUserId
            });

            userServerCount[serverUserId] = (userServerCount[serverUserId] || 1) - 1;
          }
        }
      } catch (error) {
        console.error(`Error processing server ${serverId}:`, error);
      }
    }

      for (const user of users) {
      const userId = user.attributes.id;
      const username = user.attributes.username;
      
      if (user.attributes.root_admin) continue;
      
      if (!userServerCount[userId] || userServerCount[userId] === 0) {
        try {
          const deleteResponse = await fetch(`${domain}/api/application/users/${userId}`, {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${plta}`,
            },
          });

          if (deleteResponse.ok) {
            deletedUsers.push({
              id: userId,
              username: username
            });
          }
        } catch (error) {
          console.error(`Error deleting user ${userId}:`, error);
        }
      }
    }

    let report = `✅ **PROSES PEMBERSIHAN SELESAI**\n\n`;

    if (deletedServers.length > 0) {
      report += `🗑️ **Server yang dihapus:** ${deletedServers.length}\n`;
      deletedServers.forEach(server => {
        report += `└ ID: ${server.id} | ${server.name}\n`;
      });
      report += `\n`;
    } else {
      report += `📊 Tidak ada server offline yang dihapus\n\n`;
    }

    if (deletedUsers.length > 0) {
      report += `👤 **User yang dihapus:** ${deletedUsers.length}\n`;
      deletedUsers.forEach(user => {
        report += `└ ID: ${user.id} | ${user.username}\n`;
      });
    } else {
      report += `📊 Tidak ada user tanpa server yang dihapus`;
    }

    report += `\n\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;

    bot.sendMessage(chatId, report);

  } catch (error) {
    console.error('Error in /clear command:', error);
    bot.sendMessage(
      chatId,
      `❌ Terjadi kesalahan saat melakukan pembersihan:\n\`\`\`${error.message}\`\`\``,
      { parse_mode: "Markdown" }
    );
  }
});

// listsrv
bot.onText(/\/listsrv/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  // Check if the user is the Owner
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "KHUSUS OWNER TOLOL SONO MINTA ADD OWNER SAMA NEKO...",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/Neneko20" }],
          ],
        },
      }
    );
    return;
  }
  let page = 1; // Mengubah penggunaan args[0] yang tidak didefinisikan sebelumnya
  try {
    let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
      // Menggunakan backticks untuk string literal
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });
    let res = await f.json();
    let servers = res.data;
    let messageText = "Daftar server aktif yang dimiliki:\n\n";
    for (let server of servers) {
      let s = server.attributes;

      let f3 = await fetch(
        `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${pltc}`,
          },
        }
      );
      let data = await f3.json();
      let status = data.attributes ? data.attributes.current_state : s.status;

      messageText += `ID Server: ${s.id}\n`;
      messageText += `Nama Server: ${s.name}\n`;
      messageText += `Status: ${status}\n\n`;
    }

    bot.sendMessage(chatId, messageText);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
  }
});

//Installprotect 
   bot.onText(/^\/installprotect1 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect1 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect1 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect1.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect2 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect2 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect2 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect2 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect2.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 2...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect3 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect3 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect3 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect3 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect3.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 3...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect4 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect4 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect4 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect4 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect4.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 4...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect5 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect5 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect5 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect5 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect5.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 5...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect6 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect6 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect6 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect6 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect6.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 6...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect7 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect7 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect7 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect7 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect7.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 7...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect8 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect8 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect8 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect8 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect8.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 8...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotect9 (versi SSH2) ────────────────────
bot.onText(/^\/installprotect9 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect9 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotect9 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/installprotectpanel/main/installprotect9.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 9...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *Instalasi selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /installprotectall (versi SSH2) ────────────────────
bot.onText(/^\/installprotectall (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotectall ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/installprotectall ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scripts = [
    'installprotect1.sh',
    'installprotect2.sh',
    'installprotect3.sh',
    'installprotect4.sh',
    'installprotect5.sh',
    'installprotect6.sh',
    'installprotect7.sh',
    'installprotect8.sh',
    'installprotect9.sh'
  ];

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai instalasi Protect Panel 1-9...`, { parse_mode: 'Markdown' });

  conn.on('ready', async () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses instalasi semua Protect Panel sedang berjalan...');

    for (let i = 0; i < scripts.length; i++) {
      const scriptURL = `https://raw.githubusercontent.com/Neko403/installprotectpanel/main/${scripts[i]}`;
      bot.sendMessage(chatId, `🚀 Memulai instalasi *${scripts[i]}*...`, { parse_mode: 'Markdown' });

      await new Promise((resolve) => {
        conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
          if (err) {
            bot.sendMessage(chatId, `❌ Gagal mengeksekusi ${scripts[i]}:\n\`${err.message}\``, { parse_mode: 'Markdown' });
            return resolve();
          }

          let output = '';

          stream.on('data', (data) => {
            output += data.toString();
          });

          stream.stderr.on('data', (data) => {
            output += `\n[ERROR] ${data.toString()}`;
          });

          stream.on('close', () => {
            const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
            bot.sendMessage(chatId, `✅ *${scripts[i]} selesai!*\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, { parse_mode: 'Markdown' });
            resolve();
          });
        });
      });
    }

    conn.end();
    bot.sendMessage(chatId, '🎉 Semua instalasi Protect Panel 1-9 selesai!', { parse_mode: 'Markdown' });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, { parse_mode: 'Markdown' });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect1 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect1 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect1 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect1 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect1.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 1 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 1 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect2 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect2 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect2 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect2 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect2.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai uninstall Protect 2 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 2 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect3 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect3 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect3 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect3 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect3.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 3 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 3 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect4 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect4 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect4 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect4 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect4.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 4 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 4 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect5 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect5 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect5 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect5 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect5.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 5 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 5 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect6 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect6 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect6 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect6 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect6.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 6 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 6 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect7 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect7 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect7 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect7 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect7.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 7 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 7 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect8 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect8 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect8 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect8 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect8.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 8 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 8 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotect9 (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotect9 (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect9 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotect9 ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scriptURL = 'https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/uninstallprotect9.sh';

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect 9 Panel...`, { parse_mode: 'Markdown' });

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses Uninstall sedang berjalan...');

    // Jalankan skrip install via SSH
    conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
      }

      let output = '';

      stream.on('data', (data) => {
        output += data.toString();
      });

      stream.stderr.on('data', (data) => {
        output += `\n[ERROR] ${data.toString()}`;
      });

      stream.on('close', () => {
        conn.end();

        const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
        bot.sendMessage(chatId, `✅ *uninstall protect 9 selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
          parse_mode: 'Markdown'
        });
      });
    });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
      parse_mode: 'Markdown'
    });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});

// ─── /uninstallprotectall (versi SSH2) ────────────────────
bot.onText(/^\/uninstallprotectall (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Validasi owner
  if (userId.toString() !== owner) {
    return bot.sendMessage(chatId, '❌ Hanya owner yang bisa menggunakan perintah ini!');
  }

  // Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotectall ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const [ipvps, pwvps] = input.split('|').map(i => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(chatId, '❌ Salah format!\nGunakan seperti ini:\n`/uninstallprotectall ipvps|pwvps`', { parse_mode: 'Markdown' });
  }

  const conn = new Client();
  const scripts = [
    'uninstallprotect1.sh',
    'uninstallprotect2.sh',
    'uninstallprotect3.sh',
    'uninstallprotect4.sh',
    'uninstallprotect5.sh',
    'uninstallprotect6.sh',
    'uninstallprotect7.sh',
    'uninstallprotect8.sh',
    'uninstallprotect9.sh'
  ];

  bot.sendMessage(chatId, `⏳ Menghubungkan ke VPS *${ipvps}* dan mulai Uninstall Protect Panel 1-9...`, { parse_mode: 'Markdown' });

  conn.on('ready', async () => {
    bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Proses uninstall semua Protect Panel sedang berjalan...');

    for (let i = 0; i < scripts.length; i++) {
      const scriptURL = `https://raw.githubusercontent.com/Neko403/uninstallprotectpanel/main/${scripts[i]}`;
      bot.sendMessage(chatId, `🚀 Memulai uninstall *${scripts[i]}*...`, { parse_mode: 'Markdown' });

      await new Promise((resolve) => {
        conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
          if (err) {
            bot.sendMessage(chatId, `❌ Gagal mengeksekusi ${scripts[i]}:\n\`${err.message}\``, { parse_mode: 'Markdown' });
            return resolve();
          }

          let output = '';

          stream.on('data', (data) => {
            output += data.toString();
          });

          stream.stderr.on('data', (data) => {
            output += `\n[ERROR] ${data.toString()}`;
          });

          stream.on('close', () => {
            const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
            bot.sendMessage(chatId, `✅ *${scripts[i]} selesai!*\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, { parse_mode: 'Markdown' });
            resolve();
          });
        });
      });
    }

    conn.end();
    bot.sendMessage(chatId, '🎉 Semua uninstall Protect Panel 1-9 selesai!', { parse_mode: 'Markdown' });
  });

  conn.on('error', (err) => {
    bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, { parse_mode: 'Markdown' });
  });

  conn.connect({
    host: ipvps,
    port: 22,
    username: 'root',
    password: pwvps
  });
});
    
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listadmin
bot.onText(/\/listadmin/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "KHUSUS OWNER TOLOL SONO MINTA ADD OWNER SAMA NEKO'..",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/Neneko20" }],
          ],
        },
      }
    );
    return;
  }
  let page = "1";
  try {
    let f = await fetch(`${domain}/api/application/users?page=${page}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });
    let res = await f.json();
    let users = res.data;
    let messageText = "Berikut list admin :\n\n";
    for (let user of users) {
      let u = user.attributes;
      if (u.root_admin) {
        messageText += `🆔 ID: ${u.id} - 🌟 Status: ${
          u.attributes?.user?.server_limit === null ? "Inactive" : "Active"
        }\n`;
        messageText += `${u.username}\n`;
        messageText += `${u.first_name} ${u.last_name}\n\n`;
        messageText += "𝗕𝗬 𝗡𝗘𝗡𝗘𝗞𝗢";
      }
    }
    messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
    messageText += `Total Admin: ${res.meta.pagination.count}`;
    const keyboard = [
      [
        {
          text: "BACK",
          callback_data: JSON.stringify({
            action: "back",
            page: parseInt(res.meta.pagination.current_page) - 1,
          }),
        },
        {
          text: "NEXT",
          callback_data: JSON.stringify({
            action: "next",
            page: parseInt(res.meta.pagination.current_page) + 1,
          }),
        },
      ],
    ];
    bot.sendMessage(chatId, messageText, {
      reply_markup: {
        inline_keyboard: keyboard,
      },
    });
    //▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
    // batas akhir
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
  }
});